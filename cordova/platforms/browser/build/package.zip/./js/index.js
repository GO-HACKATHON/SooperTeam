// (c) 2013-2015 Don Coleman
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//	 http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/* global mainPage, deviceList, refreshButton, statusDiv */
/* global detailPage, messageInput, disconnectButton */
/* global cordova, bluetoothSerial  */
/* jshint browser: true , devel: true*/
'use strict';

var app = {
	initialize: function() {
		var TOUCH_START = 'touchstart';
		if (window.navigator.msPointerEnabled) { // windows phone
			TOUCH_START = 'MSPointerDown';
		}
		document.addEventListener('deviceready', this.onDeviceReady, false);
		refreshButton.addEventListener(TOUCH_START, this.refreshDeviceList, false);
		disconnectButton.addEventListener(TOUCH_START, this.disconnect, false);
		deviceList.addEventListener('touchstart', this.connect, false);

		this.showMainPage();
	},
	onDeviceReady: function() {
		bluetoothSerial.list(function (devices) {
			var option;

			// remove existing devices
			deviceList.innerHTML = "";
			app.setStatus("");

			devices.forEach(function(device) {

				var listItem = document.createElement('li'),
					html = '<b>' + device.name + '</b><br/>' + device.id;

				listItem.innerHTML = html;

				if (cordova.platformId === 'windowsphone') {
				  // This is a temporary hack until I get the list tap working
				  var button = document.createElement('button');
				  button.innerHTML = "Hubungkan";
				  button.addEventListener('click', app.connect, false);
				  button.dataset = {};
				  button.dataset.deviceId = device.id;
				  listItem.appendChild(button);
				} else {
				  listItem.dataset.deviceId = device.id;
				}
				deviceList.appendChild(listItem);
			});

			if (devices.length === 0) {
				option = document.createElement('option');
				option.innerHTML = "Tidak menemukan perangkat Bluetooth.";
				deviceList.appendChild(option);

				if (cordova.platformId === "ios") { // BLE
					app.setStatus("Tidak menemukan perangkat Bluetooth.");
				} else { // Android or Windows Phone
					app.setStatus("Pairing terlebih dahulu perangkat Bluetooth.");
				}

			} else {
				app.setStatus("Menemukan " + devices.length + " perangkat.");
			}

		}, app.onError);
	},
	connect: function(e) {
		var deviceId = e.target.dataset.deviceId;
		if (!deviceId) { // try the parent
			deviceId = e.target.parentNode.dataset.deviceId;
		}

		bluetoothSerial.connect(deviceId, function () {
			app.setStatus("Terkoneksi");
			app.showDetailPage();
		}, app.onError);
	},
	sendData: function(event) {
		var success = function() {};
		var failure = function() {
			alert("Gagal mengirim perintah ke modul.");
		};
		bluetoothSerial.write(event, success, failure);
	},
	disconnect: function(event) {
		sessCmd.innerHTML = "";
		bluetoothSerial.disconnect(app.showMainPage, app.onError);
	},
	showMainPage: function() {
		mainPage.style.display = "";
		authPage.style.display = "none";
		detailPage.style.display = "none";
		passwordGantiPage.style.display = "none";
	},
	showDetailPage: function() {
		mainPage.style.display = "none";
		authPage.style.display = "none";
		detailPage.style.display = "";
		passwordGantiPage.style.display = "none";
	},
	setStatus: function(message) {
		window.clearTimeout(app.statusTimeout);
		statusDiv.innerHTML = message;
		statusDiv.className = 'fadein';

		// automatically clear the status with a timer
		app.statusTimeout = setTimeout(function () {
			statusDiv.className = 'fadeout';
		}, 5000);
	},
	onError: function(reason) {
		alert("ERROR: " + reason); // real apps should use notification.alert
	}
};